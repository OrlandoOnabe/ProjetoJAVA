package model;


public class Administrador extends Pessoa{

    public Administrador() {
    }

    public Administrador(String nome, String CPF, String senha) {
        super(CPF, nome, senha);
    }
    
}
