package Projeto;

import view_investidor.Login_Investidor;

//Projeto realizado por:
//Orlando Nagrockis Bertholdo RA: 24.223.003-5
//Morgana Rodrigues Zanetti RA: 24.223.010-0


public class ExchangeDeCriptomoedas {
    public static void main(String[] args) {
        Login_Investidor j = new Login_Investidor();
        j.setVisible(true);
    }
}
