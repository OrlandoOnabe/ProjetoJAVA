package Projeto;

import view_investidor.Login_Investidor;




public class ExchangeDeCriptomoedas {
    public static void main(String[] args) {
        Login_Investidor j = new Login_Investidor();
        j.setVisible(true);
    }
}
