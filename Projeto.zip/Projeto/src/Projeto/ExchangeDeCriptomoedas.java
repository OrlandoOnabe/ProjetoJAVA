package Projeto;

import view_administrador.Login_Administrador;
import view_investidor.Login_Investidor;




public class ExchangeDeCriptomoedas {
    public static void main(String[] args) {
        Login_Administrador j = new Login_Administrador();
        j.setVisible(true);
    }
}
