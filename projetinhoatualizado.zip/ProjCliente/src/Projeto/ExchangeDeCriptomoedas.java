package Projeto;

import view_administrador.Cadastro_Administrador;


public class ExchangeDeCriptomoedas {
    public static void main(String[] args) {
        Cadastro_Administrador j = new Cadastro_Administrador();
        j.setVisible(true);
    }
}
