package controller_administrador;

public class ControllerMenu_Administrador {
    
}
