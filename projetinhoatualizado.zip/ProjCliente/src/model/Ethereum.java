package model;


public class Ethereum extends Moedas{
    
}
