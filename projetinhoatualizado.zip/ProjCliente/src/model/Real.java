package model;


public class Real extends Moedas{
    
}
