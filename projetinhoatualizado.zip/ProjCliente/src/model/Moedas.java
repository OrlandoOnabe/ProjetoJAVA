package model;


public class Moedas extends Carteira{
    
}
