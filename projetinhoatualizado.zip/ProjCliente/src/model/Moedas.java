package model;


public class Moedas{
    public double saldo;
    
    public Moedas() {
    }

    public Moedas(double saldo) {
        this.saldo = saldo;
        
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    
}
