package model;


public class Ripple extends Moedas{
    
}
