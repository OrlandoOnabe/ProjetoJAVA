/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author xblak
 */
public class Ripple {
    
    public Ripple() {
        
    }
    
    
    public void exibirInformacoes(){
        System.out.println("-----INFORMACOES SOBRE A MOEDA-----");
        System.out.println("Taxa de Compra : 1%");
        System.out.println("Taxa de Venda : 1%");
        
        System.out.println("----VALOR DA MOEDA----");
        System.out.println("1 BRL (Real brasileiro) = 0.34 XRP (Ripple)");
        
        //Seria bom adicionar uma função aqui para receber o valor da moeda atualizada
        //tipo:
        
        /*public Conversao(){
            ValorConvertido = Real * 0.34157664;
        }    
        */
    }   
}
