package model;


public class Bitcoin extends Moedas{
    
}
