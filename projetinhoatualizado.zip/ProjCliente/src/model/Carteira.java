package model;


public class Carteira{ 
    Investidor investidor = new Investidor();

    public Carteira() {
    }
    
}
