package model;


public class Carteira extends Investidor{ 
    
}
